"""
Petal parser — starter skeleton.

YOUR TASK
=========
Implement a parser for the Petal language as specified in `docs/SPEC.md`.
Your parser must expose two callables:

    parse(src: str) -> dict
        Parse a Petal source string and return its AST as a Python dict
        whose structure exactly matches the schema in section 3 of SPEC.md.

    parse_file(path: str) -> dict
        Read the file at `path` and call parse() on its contents.

The module also runs as a script:

    python3 parser.py <file.petal>
        Print the parsed AST as pretty JSON to stdout.

WHAT GETS GRADED
================
Your AST output (after `json.dumps(ast, sort_keys=True)`) must equal the
ground-truth AST (also json-canonicalised). The public test runner in
`public_test.py` checks the 5 visible examples; the instructor's hidden
test runner checks 20 additional cases.

YOU MAY:
- Restructure this file however you like (multiple classes, helpers, etc).
- Use only the Python standard library. No third-party packages.
- Use AI assistance (Claude Code, etc.) — but read SPEC.md yourself; it
  contains traps that won't survive a naive prompt.

YOU MAY NOT:
- Use any existing parser library (lark, ply, pyparsing, etc.).
- Import or read the reference parser (you don't have it anyway).
- Modify SPEC.md, examples/, or any test runner.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path


def parse(src: str) -> dict:
    """Parse Petal source code and return the AST as a dict.

    Replace this stub with your implementation.
    """
    raise NotImplementedError("Implement me — see docs/SPEC.md")


def parse_file(path: str | Path) -> dict:
    return parse(Path(path).read_text())


# ---------------------------------------------------------------------------
# Hints / suggested structure (delete or keep as you like)
# ---------------------------------------------------------------------------
#
# A clean recursive-descent design has roughly four phases:
#
#   1. Pre-processing
#        - Reject tab characters anywhere in source.
#        - Normalise line endings to \n.
#        - Strip comments while preserving newlines and column positions.
#
#   2. Tokenization
#        - Read the source character by character. At each step, try multi-
#          character operator tokens (e.g. "==>", "<->", "..") before single
#          characters. Maximal munch is essential.
#        - Hyphenated keywords ("on-violation", "retry-with") and "when?" need
#          special handling — see SPEC §1.5.
#        - Emit a flat token stream including NEWLINE tokens.
#
#   3. Indentation
#        - In a second pass, insert INDENT and DEDENT tokens based on the
#          column of the first non-whitespace token on each significant line.
#          Blank lines and comment-only lines do not affect indentation.
#
#   4. Parsing
#        - Recursive descent over the token stream. One method per grammar
#          production. Track operator precedence with a fall-through chain
#          (parse_impl -> parse_or -> parse_and -> ...).
#
# The AST node names listed in SPEC §3 are exact — copy them character for
# character.
#
# Tips:
# - Run `python3 parser.py examples/01_simple.petal` early and often.
# - `diff <(jq -S . your.json) <(jq -S . examples/01_simple.ast.json)` is your
#   friend.
# - The public examples and their expected ASTs are in `examples/`. Pass them
#   all before worrying about the hidden tests.


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _main(argv: list[str]) -> int:
    if len(argv) != 2:
        print("usage: python3 parser.py <file.petal>", file=sys.stderr)
        return 2
    try:
        ast = parse_file(argv[1])
    except NotImplementedError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(ast, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(_main(sys.argv))
