# Petal Language Specification (v0.1)

Petal is a domain-specific language for describing **agent contracts** — preconditions, postconditions, invariants, and failure-handling policies for individual agents in a multi-agent system. This document is the **complete and authoritative** specification. Your parser must implement exactly this language; anything not specified here is **not** part of the language.

---

## 1. Lexical structure

### 1.1 Source encoding

Petal source files are UTF-8. Only ASCII characters appear inside tokens; non-ASCII characters appear only inside string literals or comments.

### 1.2 Whitespace

The only valid in-line whitespace is the space character (`U+0020`). **Tabs are forbidden anywhere in source**; a parser must reject any file containing `\t`.

Lines are terminated by `\n`. `\r\n` is normalized to `\n` before lexing.

### 1.3 Comments

Two comment styles are supported:

- **Line comment**: `-- ...` — everything from `--` to end of line is a comment.
- **Block comment**: `(* ... *)` — **nestable**. The parser must track nesting depth: `(* a (* b *) c *)` is **one** comment, not two.

Comments are equivalent to a single space character for tokenization purposes — they never produce a token, but they do separate adjacent tokens.

### 1.4 Indentation

Petal is indentation-sensitive. The indent level of a line is the number of leading space characters before the first non-space character. **Blank lines and comment-only lines do not affect indentation**; they are simply skipped when computing block structure.

A line ending with `:` (after stripping comments/whitespace) opens a **new indented block**. The first statement of the block must be on a subsequent line whose indent is **strictly greater than** the line that opened the block. All statements within the same block must share **identical** indent. The block ends when a line returns to an indent **less than or equal to** the indent of the opening line.

The reserved token `.end` (one token, with a literal dot) closes a top-level `contract` declaration; it must appear at the **same** indent as its opening `contract` keyword.

### 1.5 Keywords

The following are reserved and may not be used as identifiers:

```
contract  requires  ensures   invariant  forall  in
when?     on-violation  retry-with  triggers
```

Note the hyphens in `on-violation` and `retry-with`, and the trailing `?` in `when?`. These characters are part of the keyword, not separate tokens. **Identifiers may not contain `-` or `?`.**

### 1.6 Identifiers

```
IDENT  ::=  [a-zA-Z_][a-zA-Z0-9_]*
```

No hyphens, no question marks. Identifiers are case-sensitive. `Agent` and `agent` are distinct.

### 1.7 Numeric literals

```
NUMBER ::= '0x' [0-9a-fA-F]+        (* hexadecimal integer *)
         | [0-9]+ '.' [0-9]+         (* decimal float       *)
         | [0-9]+                    (* decimal integer     *)
```

A leading `+` or `-` is **not** part of a number literal; it is the unary or binary operator.

### 1.8 String literals

```
STRING ::= '"' ( escape | <any char except " or \> )* '"'
escape ::= '\n' | '\t' | '\"' | '\\'
```

A newline character inside a string literal (without escape) is an error. Strings are single-line only.

### 1.9 Operators and punctuation

Tokenize using **maximal munch**: the longest matching operator wins. Operator tokens:

```
==>   ||   &&   ??   !!   ~~   <->   ==   !=   <=   >=   <   >
+     -    *    /    !    ..   ::    .end
(     )    [    ]    {    }    ,     :    =     .
```

Particular care:
- `==>` is one token, never `==` followed by `>`.
- `<->` is one token, never `<` `-` `>`.
- `..` is one token (used in ranges); a single `.` is the member-access operator.
- `.end` is one token; `.` followed by IDENT `end` is **not** equivalent (the lexer must consume `.end` as a unit when it appears at the start of a token position).
- `::` is one token, distinct from two `:`s.

---

## 2. Grammar

### 2.1 Top level

```
Program        := ContractDecl*
ContractDecl   := 'contract' IDENT '::' IDENT BLOCK Clause+ ENDBLOCK '.end'
Clause         := RequiresClause | EnsuresClause | InvariantClause | OnViolationClause
```

The header `contract NAME :: TYPE` has **no trailing colon** and is itself **not** a block-opener. The body of a contract begins on the first subsequent non-blank, non-comment line whose indent is strictly greater than the `contract` keyword's indent. The body ends when the literal token `.end` appears at the **same** indent as the `contract` keyword. Each `Clause` keyword is itself a block-opener (`:` at end of line) and introduces its own indented body.

### 2.2 Clauses

```
RequiresClause     := 'requires:'      BLOCK Expr+
EnsuresClause      := 'ensures:'       BLOCK EnsuresStmt+
InvariantClause    := 'invariant:'     BLOCK InvariantStmt+
OnViolationClause  := 'on-violation:'  BLOCK Setting+

EnsuresStmt        := WhenStmt | Expr
InvariantStmt      := ForallStmt | Expr
WhenStmt           := 'when?' Expr ':' BLOCK EnsuresStmt+
ForallStmt         := 'forall' IDENT 'in' Expr ':' BLOCK InvariantStmt+
Setting            := IDENT      ('=' | ':') Expr
                    | 'retry-with' ':'        IDENT
```

Each clause may appear **at most once** within a contract. They may appear in any order, but the canonical order in the AST is the order they appear in source.

### 2.3 Expressions

Operator precedence, **lowest to highest**:

| # | Operators                       | Assoc          |
|---|---------------------------------|----------------|
| 1 | `==>`                           | right          |
| 2 | `\|\|`                          | left           |
| 3 | `&&`                            | left           |
| 4 | `??` `!!` `~~` `<->` `triggers` `in` | non-assoc |
| 5 | `==` `!=`                       | non-assoc      |
| 6 | `<` `>` `<=` `>=`               | non-assoc      |
| 7 | `+` `-`                         | left           |
| 8 | `*` `/`                         | left           |
| 9 | `!` (unary prefix)              | prefix         |
| 10| `.` (member) `[ ]` (index) `( )` (call) | left   |

Non-associative means `a == b == c` is a **parse error** — must be parenthesized.

```
Primary    := NUMBER | STRING | IDENT
            | '(' Expr ')'
            | '{' ExprList? '}'          (* set literal     *)
            | '[' Expr '..' Expr ']'     (* range, MUST have both bounds *)
            | '[' ExprList? ']'          (* list literal    *)
ExprList   := Expr (',' Expr)*
```

A `[ ... ]` containing exactly two expressions separated by `..` is a **Range**, not a List. A `[ a, b, c ]` with `,` is a **List**. An empty `[]` is an empty List.

### 2.4 Type expression after `::`

Currently only a bare IDENT (no qualifiers, no generics).

---

## 3. AST output format

Your parser must produce a JSON tree with the node types below. Field order is irrelevant; field names and values must match exactly.

```
Program       { type, contracts: [...] }
Contract      { type, name, agent_type, clauses: [...] }
Requires      { type, items: [Expr, ...] }
Ensures       { type, items: [EnsuresStmt, ...] }
Invariant     { type, items: [InvariantStmt, ...] }
OnViolation   { type, settings: [Setting, ...] }
Setting       { type, key, sep, value }     // sep is "=" or ":"
Forall        { type, var, iter, body: [InvariantStmt, ...] }
When          { type, cond, body: [EnsuresStmt, ...] }
BinOp         { type, op, left, right }
Unary         { type, op, operand }
Member        { type, object, field }
Call          { type, func, args: [Expr, ...] }
Index         { type, object, index }
Identifier    { type, name }
Number        { type, value }               // JSON number (int or float)
String        { type, value }               // decoded string (escapes resolved)
Set           { type, elements: [Expr, ...] }
List          { type, elements: [Expr, ...] }
Range         { type, low, high }
```

The `type` field carries the node name verbatim (`"Program"`, `"BinOp"`, etc.).

For numeric literals: hex `0x1F` → `{"type": "Number", "value": 31}`. Decimal `1.5` → `{"type": "Number", "value": 1.5}`. Integer `100` → `{"type": "Number", "value": 100}`.

For strings: escapes are resolved. `"a\nb"` → `{"type": "String", "value": "a\nb"}`.

---

## 4. Error handling

For this assignment, you **do not** need to produce informative error messages. If the input is well-formed, produce its AST. If the input is malformed, you may raise any exception or print any error — the public/hidden test runners count a test as failing if the AST does not exactly match, regardless of reason.

All 25 test cases (5 public + 20 hidden) are well-formed Petal programs. None of the tests deliberately feed your parser malformed input. Your job is to parse correct programs correctly, not to detect errors.

---

## 5. Reference example

```petal
-- A simple analyzer contract.
contract analyzer :: Agent
  requires:
    input ?? source_code
    tools !! { read_file, grep }

  ensures:
    output ~~ Notes
    cost <-> [0 .. 100]
    when? sanitizer_enabled:
      output triggers sanitizer || cost <= 50

  invariant:
    forall step in trace:
      step.tool_call ==> step.tool_call in tools

  on-violation:
    severity = high
    retry-with: prompt_rewrite
.end
```

The corresponding AST (abbreviated) is available in `examples/01_simple.ast.json`.
