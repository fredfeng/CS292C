# Petal Parser — CS292C Assignment

You will implement a parser for **Petal**, a small but deliberately tricky language for specifying agent contracts. Petal looks superficially like Python or HCL, but every recognisable surface feature has a twist. Reading `docs/SPEC.md` carefully is the assignment.

## Setup

```bash
cd petal-parser-exercise
python3 --version          # 3.10 or newer
python3 public_test.py     # runs the 5 visible examples; should report 0 / 5 before you start
```

No third-party libraries. Standard library only.

## What you implement

Edit `starter/parser.py`. Your module must expose:

```python
def parse(src: str) -> dict: ...
def parse_file(path: str | Path) -> dict: ...
```

`parse` takes a Petal source string and returns its AST as a Python dictionary matching the schema in `docs/SPEC.md` §3.

You may restructure the file however you like, add helper modules, etc. — as long as `parse` and `parse_file` are importable from `starter.parser`.

## What you may NOT use

- Any third-party parsing library (`lark`, `ply`, `pyparsing`, `antlr`, `tree-sitter`, `tatsu`, ...). This is a from-scratch exercise.
- Any oracle for the reference AST. You have not been given the reference parser.

You **may** use AI assistance (Claude Code, Copilot, ChatGPT, ...). However, naive prompting will not pass the hidden tests. The spec contains specific traps that survive only careful reading.

## How you are graded

Total: **100 points**.

| Component        | Tests | Points each | Subtotal |
|------------------|-------|-------------|----------|
| Public examples  | 5     | 4           | 20       |
| Hidden tests     | 20    | 4           | 80       |

A test passes iff `json.dumps(your_ast, sort_keys=True)` equals `json.dumps(expected_ast, sort_keys=True)`. There is no partial credit per test — the AST matches or it does not.

You can run the public tests yourself any time:

```bash
python3 public_test.py
```

You cannot run the hidden tests; the instructor runs them on your submission.

## Files in this repository

```
petal-parser-exercise/
├── README.md                  ← you are here
├── docs/SPEC.md               ← the authoritative language definition
├── examples/                  ← 5 .petal files + their expected .ast.json
├── starter/parser.py          ← edit this
├── public_test.py             ← runs your parser against examples/
├── hidden_test.py             ← instructor uses this; you can read it if curious
└── (hidden_tests/ withheld)   ← only on the grading machine
```

## Suggested workflow

1. Read `docs/SPEC.md` end to end. The traps are stated explicitly.
2. Open `examples/01_simple.petal` and `examples/01_simple.ast.json` side by side. Convince yourself of the AST shape.
3. Sketch your lexer first. The hardest lexical features in Petal are:
   - hyphenated keywords (`on-violation`, `retry-with`)
   - `when?` keyword with a trailing `?`
   - nested block comments `(* (* ... *) *)`
   - maximal-munch tokens like `==>`, `<->`, `..`
4. Sketch your indentation handler next. Petal is indentation-sensitive but the indent width is not fixed.
5. Then write the recursive-descent parser. Use one method per grammar production. Track operator precedence with a chain of fall-through methods (lowest level calls next-higher level).
6. Run `public_test.py` early and often.

## Submission

Submit a single zip containing your `starter/` directory and any extra modules you wrote. The instructor will place it in a fresh checkout of this repository and run `python3 hidden_test.py <your_dir>`.

## Academic integrity

You may discuss the spec and high-level design with classmates. You may use AI tools. You must write the code yourself. Submitting code lifted from another student or from an existing Petal-like parser online (if one ever appears) is a violation.

## FAQ

**"My output looks right but a test fails."**
JSON equality is order-sensitive at the array level (and order-insensitive at the object level, since we canonicalise with `sort_keys=True`). The list of statements in a block must be in source order. The list of clauses in a contract must be in source order.

**"Does my parser need to reject malformed input?"**
No. All 25 tests are well-formed Petal. You may raise any exception or print any error on malformed input; nothing in the grader looks at that.

**"How fast does it need to be?"**
Any sensible recursive-descent implementation finishes all 25 tests in under a second. No performance grading.

**"Can I write it in Rust / Go / OCaml?"**
For this assignment, Python is required because the grader imports your `parse` function directly. If you want to write the core in another language, you may shell out to a binary from inside `parse(src)` — but you are responsible for making it work on the grading machine.
