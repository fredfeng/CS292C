"""
Hidden test runner — INSTRUCTOR ONLY.

Runs the student's parser against the 20 hidden adversarial tests in
hidden_tests/, plus the 5 public examples for completeness. Emits a
score and a JSON report suitable for grading.

Usage:
    python3 hidden_test.py <student_dir>

Where <student_dir> contains the student's parser.py. The script will
import it from there.

Scoring rubric (matches docs/SPEC.md §6):
    Public examples (5 tests):    4 points each = 20 points total
    Hidden tests   (20 tests):    4 points each = 80 points total
    Maximum score: 100 points.

The script exits 0 if it ran end-to-end (regardless of student score).
A non-zero exit indicates a configuration or import error.
"""

from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path


HERE = Path(__file__).resolve().parent


def canonical(ast: dict) -> str:
    return json.dumps(ast, sort_keys=True, ensure_ascii=False)


def load_parser(student_dir: Path):
    parser_path = student_dir / "parser.py"
    if not parser_path.exists():
        raise FileNotFoundError(f"No parser.py at {parser_path}")
    spec = importlib.util.spec_from_file_location("student_parser", parser_path)
    mod = importlib.util.module_from_spec(spec)
    # Register in sys.modules so dataclasses (and similar) can look it up.
    sys.modules["student_parser"] = mod
    spec.loader.exec_module(mod)
    parse = getattr(mod, "parse", None)
    if parse is None:
        raise AttributeError("Student parser.py has no `parse` function")
    return parse


def run_suite(parse, suite_dir: Path, points_per_test: int) -> tuple[int, list[dict]]:
    earned = 0
    results = []
    cases = sorted(suite_dir.glob("*.petal"))
    for petal in cases:
        expected_path = petal.with_suffix(".ast.json")
        if not expected_path.exists():
            results.append({"name": petal.name, "status": "skip", "reason": "no .ast.json"})
            continue
        expected = json.loads(expected_path.read_text())
        src = petal.read_text()
        try:
            got = parse(src)
            ok = canonical(got) == canonical(expected)
        except Exception as exc:
            results.append({"name": petal.name, "status": "error",
                            "reason": f"{type(exc).__name__}: {exc}"})
            continue
        if ok:
            earned += points_per_test
            results.append({"name": petal.name, "status": "pass"})
        else:
            results.append({"name": petal.name, "status": "fail"})
    return earned, results


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print("usage: python3 hidden_test.py <student_dir>", file=sys.stderr)
        return 2
    student_dir = Path(argv[1]).resolve()
    parse = load_parser(student_dir)

    public_pts, public_results = run_suite(parse, HERE / "examples", points_per_test=4)
    hidden_pts, hidden_results = run_suite(parse, HERE / "hidden_tests", points_per_test=4)
    total = public_pts + hidden_pts

    report = {
        "student_dir": str(student_dir),
        "public_score": public_pts,
        "public_max": 4 * len(public_results),
        "hidden_score": hidden_pts,
        "hidden_max": 4 * len(hidden_results),
        "total": total,
        "total_max": 4 * (len(public_results) + len(hidden_results)),
        "public_results": public_results,
        "hidden_results": hidden_results,
    }

    print(json.dumps(report, indent=2))

    # Human-readable summary on stderr so a > redirect captures only JSON
    print(
        f"\n=== {student_dir.name} ===\n"
        f"  Public:  {public_pts} / {report['public_max']}\n"
        f"  Hidden:  {hidden_pts} / {report['hidden_max']}\n"
        f"  Total:   {total} / {report['total_max']}",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
