"""
Public test runner.

Reads every .petal / .ast.json pair in examples/, runs your parser on
each .petal, and compares the result to the expected AST.

Usage:
    python3 public_test.py                  # uses starter/parser.py
    python3 public_test.py <parser_module>  # e.g. python3 public_test.py mysubmission.parser
"""

from __future__ import annotations

import importlib
import json
import sys
from pathlib import Path


HERE = Path(__file__).resolve().parent
EXAMPLES = HERE / "examples"


def canonical(ast: dict) -> str:
    return json.dumps(ast, sort_keys=True, ensure_ascii=False)


def run(parser_module_name: str = "starter.parser") -> int:
    sys.path.insert(0, str(HERE))
    try:
        mod = importlib.import_module(parser_module_name)
    except Exception as exc:
        print(f"FAILED to import {parser_module_name}: {exc}")
        return 1

    parse = getattr(mod, "parse", None)
    if parse is None:
        print(f"FAILED: {parser_module_name} has no `parse` function")
        return 1

    cases = sorted(EXAMPLES.glob("*.petal"))
    if not cases:
        print(f"No .petal files in {EXAMPLES}")
        return 1

    passed = 0
    failed = 0
    for petal in cases:
        expected_path = petal.with_suffix(".ast.json")
        if not expected_path.exists():
            print(f"SKIP {petal.name} (no .ast.json)")
            continue
        expected = json.loads(expected_path.read_text())
        src = petal.read_text()
        try:
            got = parse(src)
        except Exception as exc:
            print(f"FAIL {petal.name}: {type(exc).__name__}: {exc}")
            failed += 1
            continue
        if canonical(got) == canonical(expected):
            print(f"PASS {petal.name}")
            passed += 1
        else:
            print(f"FAIL {petal.name}: AST mismatch")
            failed += 1

    total = passed + failed
    print()
    print(f"Public score: {passed} / {total}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    mod_name = sys.argv[1] if len(sys.argv) > 1 else "starter.parser"
    sys.exit(run(mod_name))
